#ifndef __SHOW_H_
#define __SHOW_H_

void show(unsigned char location,num);

#endif